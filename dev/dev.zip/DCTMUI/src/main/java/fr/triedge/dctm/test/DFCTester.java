package fr.triedge.dctm.test;

import java.io.IOException;
import java.security.GeneralSecurityException;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;

import fr.triedge.dctm.engine.DFC;

public class DFCTester {

	public static void main(String[] args) throws DfException, GeneralSecurityException, IOException {
		System.out.println("Usage: DOCBASE, HOST, USER, PASSWORD, PORT");
		String docbase = args[0];
		String host = args[1];
		String user = args[2];
		String password = args[3];
		int port = Integer.parseInt(args[4]);
		IDfSession ses = DFC.getSession(docbase, host, port, user, password);
		System.out.println("Connection to "+docbase+" successful! ["+ses+"]");
	}

}
